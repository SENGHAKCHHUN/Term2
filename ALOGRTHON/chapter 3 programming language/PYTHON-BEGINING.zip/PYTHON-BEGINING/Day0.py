# Challenge1
print("PNC")

# Challenge2
for n in range (5):
    print("Hello")

# Challenge3
age=19
print(age)

# Challenge4
value=0
value= value+2
print(value)

# Challenge5
number=19
for n in range (6):
    print(number)
    number=number+2
 
# Challenge6
age=1
while age<10:
    print(age)
    age= age+1

# Challenge7
age="My age is 14"
size="and my size is 21"
print(age,size)

#Challenge8
a = int(input("Inter Here: "))
for i in range(a):
    print(" HELLO ")
# Challenge9
v = int(input("Inter: "))
if v ==0:
    print(" Good choice ")
else:
    print("Bad choice ")
