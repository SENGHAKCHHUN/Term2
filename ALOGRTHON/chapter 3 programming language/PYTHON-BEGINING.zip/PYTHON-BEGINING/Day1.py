 #1
#  Challenge1
# x = 1
# y = 2
# value1 = (x > 5 and y == 9)
# print(value1)

#Challenge2
# value2 = (y == 1 or 2)
# print(value2)

# Challenge3
# z = 1
# value3 =(z == 5) or( z == 7 )or(z == 9 ) 
# print(value3)

#2
# if (x < 0) or ( x == 10<=15):
#     print("valid")
    
#3
# number = int(input())
# text = ""
# if (number < 10):
#     text= "To low"
# elif (number == 10 ):
#     text = "Good job"
# else:
#     text= "To high"
# print(text)


