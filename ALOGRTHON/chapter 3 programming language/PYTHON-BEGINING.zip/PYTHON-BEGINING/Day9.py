   #Hacker range
   #EX1
# text = input()
# word = False
# for i in range(len(text)):
#     if text[i] == "!":
#         word = True
# print(word)

    #EX2
# text = input()
# word = ""
# isNotword = True
# for i in (text):
#     if i == "'" and isNotword:
#         isNotword = False
#     elif i == "'" and not isNotword:
#         isNotword = True
#     elif isNotword:
#         word += i
# print(word)

     #EX3
# text = input()
# word = 0
# for i in range(len(text)):
#     if text[i] == "A":
#         word += 5
#     elif text[i] == "a":
#         word += 10
#     else:
#         word += 1
# print("The total score is: ",word)

      #EX4

# text = ""
# notqual = 1
# equal = 1
# getnaem = ""
# for i in range(3):
#     word = input()
#     if text == word:
#         equal += 1 
#         getnaem += "- " + word + str(equal) +"\n"
#     else:
#         getnaem += "- " + word + str(notqual) +"\n"
#     getnaem = word
# print(getnaem)

isTrue = True
listItem = []
array = {}
while(isTrue):
   item = input()
   if (item == 'full'):
       isTrue = False
   else:
       listItem.append(item)
for i in listItem:
    array[i] = listItem.count(i)
for u in array:
   print("- "+ u +" "+ str(array[u]))


     