    #Hackerrangeweek.15
#    EXI
# word = input()
# text1 = 0
# text2 = 0
# replace = ""
# for i in range(len(word)):
#     if word[i] == "A":
#              text1 = text1 + 1
#     if word[i] == "B":
#         text2 = text2+ 1
# if text1== 2 and text2 == 2:
#     replace = "Well done!"
# else:
#     replace = "Lost"
# print(replace)

    # EX2
# word1 = input()
# word2 = input()
# word3 = input()
# maxword = ""
# if len(word1) > len(word2) and len(word1)> len(word3):
#     maxword = word1
# elif len(word2) > len(word1) and len(word2) > len(word3):
#     maxword = word2
# else:
#     maxword = word3
# print(maxword)

    #EX3
# word = input()
# text1 = 0
# text2 = 0
# replace = ""
# for i in range(len(word)):
#     if word[i] == "A":
#              text1 = text1 + 1
#     if word[i] == "B":
#         text2 = text2+ 1
# if text1>text2:
#     replace = "WELL DONE"
# else:
#     replace = "LOST"
# print(replace)
    
   #EX4
# text = input()
# isNotOnlyA = False
# for i in range (len(text)):
#     if text[i] != "A":
#         isNotOnlyA = True
# if isNotOnlyA:
#     print("LOST")
# else:
#     print("WELL DONE")






