 #II 
 # Exercise 1
# for al in range(0,6):
#     for i in range(0,al):
#         print("", end="")
#     print("X")

 # Exercise2
# for al in range(0,6):
#     for i in range(0,al):
#         print("", end="")
#     print("X")

 # Exercise3
# w = 5
# h = 5
# Text= ""
# for he in range(h):
#     for we in range(w):
#         Text+="X"
#     Text+= "\n" 
# print(Text)

 # Exercise4
# h = 0
# k = 4
# for r in range(0,3):
#     for c in range(0,5):
#         if r==c:
#            print("X",end="")
#         elif  r==h and c==k:
#             print("X",end="")
#             h=h+1
#             k=k-1
#         else:
#             print(end=" ")
#     print()