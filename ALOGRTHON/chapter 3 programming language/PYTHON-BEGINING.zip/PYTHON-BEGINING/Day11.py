isPrincess = input("PrincessX:")
OfPrincess = input("PrincessY:")
acctions = ""
for n in range(isPrincess):
    firstvalues = 4
lastnumber = 0
allnumber =0
for i in range(int(input("number:"))):
   numberOfValues = int(input())
if i < 3 :
  allnumber= firstvalues+lastnumber
elif i > 3:
    allnumber= lastnumber
print("Result is:",allnumber)
