
#    ##
# n = 5
# text = "X"
# for i in range(n):
#     print(text)
#     text= text+"X"
 
#      ##
s1 = str(input())
s2 = str(input())
s3 = str(input())
print(s1+"-"+s2+"-"+s3 )

#    ##
# n = int(input())
# text = "X"
# for i in range(n):
#     print(text, end="")

#     #1
# n = int(input())
# text = ""
# for i in range(n):
#     text+= "X"
#     print(text)
 
#    #2
# text1 = input()
# text2 = input()
# text3 = input()
# text4 = input()
# print(len(text1), end="-")
# print(len(text2), end="-")
# print(len(text3), end="-")
# print(len(text4), end="")

#    #EX3
# n = input()
# text = ""
# for i in range(len(n)):
#     text+= "Y"
# print(text)

# #    #EX4
# word = input()
# value = ""
# if (len(word) <= 3):
#     value= "It's small!"
# elif (4 <= len(word) <= 6) or (8 <= len(word) <= 10):
#     value= "I't meduim!"
# elif (len(word) == 7):
#     value= "It's exactly the average !"
# elif (11 <= len(word)):
#     value = "It's big!"
# print(value)


#    #Ex5
# number = int(input())
# mode = input()
# if (1 < number < 10) and mode == "inside":
#     print("True")
# elif (number < 1 or number > 10) and mode =="outside":
#     print("True")
# else:
#     print("False")

#    #Ex6
# word = input()
# for i in range(len(word)):
#     word= word[:-1]
    # print(word)

#    #7

# number = int(input())
# n = ""
# for i in range(number):
#         n = n + "X"
# for i in range(number):
#         n = n[:-1]
#         print(n)


