   #EX1
# word1 = input()
# word2 = input()
# text1 = sum (1 for i in word1 if i.isupper())
# text2 = sum (1 for i in word2 if i.isupper())
# print(text1+text2)

  #EX3
# word = input()
# print("!".lower() in word.lower())

   #EX4
# text = input()
# intext = True
# ntext= ""
# for i in text:
#     if i == "'" and intext:
#         intext=False
#     elif i == "'" and not intext:
#         intext = True
#     elif intext:
#         ntext+= i
# print(ntext)

   #Ex5
# text = input("Enter text:")
# for i in range(len(text)):
#    if text[i] == "A":
#       numberOfSum = 10 
#    elif text[i] == "B":
#       numberOfSum = 20
# print(numberOfSum)


print ("WILL YOU BE MY BOYFRIEND?")
a=input('Please enter your word (yes or no):')
if a!="yes" and a!="no":
   print("Please answer my question yes or no?")

def happy_heart():
   for row in range(6):
      for col in range(7):
         if (row==0 and col%3!=0) or (row==1 and col%3==0) or (row-col==2) or (row+col==8):
            print("❤",end="")
         else:
            print(" ",end="")
         print()

# print(happy_heart())    
def write_feeling():
   print("/n I LOVE YOU")
if a=='yes':
 happy_heart().write_feeling()


