 
 #Google Form
   #1
text = ""
for i in range(5):
    text= text + str(i + 1) + ""
print(text)
   #2
text = ""
for i in range(5):
    text+= str(i +1)+"\n"
     
    #3
text = ""
for i in range(5):
  text = text + str(i+2) +"\n"
print(text)

    #4
text = "student" 
result = ""
for n in range(len(text)):
	result = result+text[n]
print(result)

    #5
for i in range(0,10):
	print(i)
    #6
for i in range(1,5,-1):
	print(i)
   
    #6
for i in range(5,1,-1):
    print(i)
    #16
number = int(input("Number="))
for i in range(1,number+1):
    print(i)

    #17
number = int(input("number="))
for i in range(0,number,2):
    print(i, end=" ")
    
    #18
number = int(input("number="))
for i in range(1,number,2):
    print(i,end =" ")
  
    #19
for n in range(-10,-1+1):
    print(n, end="")

    #20
for i in range(1,11):
    print(9,"x",i,"=",9*i)
    #21
number = int(input("number:"))
for i in range(1,11):
    print(number,"x",i,"=",number*i)