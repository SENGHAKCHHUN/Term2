#1
# number = 0
# text = ""
# while number < 5:
# 	text += "@"
# 	number += 1
# print(text)

   #2
# number = 0
# text = ""
# isLess = True
# while isLess: 
# 	text +="Z"
# 	number += 1
# 	if number == 5: 
# 		isLess = False
# print(text)

   #3


# isnb = False
# while (not isnb):
#     n = int(input())
#     if ( n != 10):
#         print("What you want!?")
#     else: 
#        isnb = True
#        print( "What you need!")
       
    #4) 
# n =  False
# while ( not n):
#     t = int(input()) 
#     if (5 <= t <= 10):
#        n = True
#        print("Crazies")
       
    #5
# you = False
# while ( not you):
#     number= int(input())
#     if ( 5<= number <=10 ):
#         you = True
#         print("You won!")

    #6
# nb = True
# times = 0
# while nb:
#     numbers = int(input())
#     times = times+ 1
#     if (5<= numbers <=10):
#         print("You won!")
#         nb = False
#     elif times == 3:
#         print("Game over!")
#         nb = False

    #7
# number = int(input("Number= "))
# text = ""
# for i in range(number):
#     text +="X"
# print(text)

   #8
# width = int(input("width="))
# height = int(input("height="))
# text = ""
# for  h in range(height):
#     for w in range(width):
#         text +="X"
#     text += "\n"
# print(text)
    
  #9
# number = int(input("number="))
# text = ""
# for i in range(number):
#     text +=" X"
# print(text)

   #10
# width = int(input("width="))
# height = int(input("height="))
# text = ""
# for  h in range(height):
#     for w in range(width):
#         text += " X"
#     text += "\n"
# print(text)

   #11
# number = int(input("number="))
# text = ""
# for i in range(number):
#     text +=" XX"
# print(text)

   #12
# width = int(input("width="))
# height = int(input("height="))
# text = ""
# for  h in range(height):
#     for w in range(width):
#         text += " XX"
#     text += "\n"
# print(text)

   #13
# number = int(input("number="))
# text = ""
# for i in range(number):
#     text+="X"
#     print(text,end=" ")
    
    #14
# number = int(input("number="))
# text = "X"
# for i in range(number):
#     text+="X"
# for i in range(number):
#     text=text[:-1]
#     print(text,end=" ")

    #15
# width = int(input("width="))
# height = int(input("height="))
# text = ""
# for  h in range(height):
#     for w in range(width):
#         for add in range(w):
#             text +="X"
#         text+=" "
#     text+="\n"
# print(text)

  #16
# width = int(input("width="))
# height = int(input("height="))
# text = ""
# for  h in range(height):
#     addw = width
#     for w in range(width):
#         for add in range(addw):
#             text +="X"
#         text+=" "
#         addw = addw-1
#     text+="\n"
# print(text)

