     #Challenge1
number = int(input("Enter: "))
if (number < 0):
    print("Positive number!")
if (number < 0):
   print("Negative number!")

   #Challenge2
number = int(input("Enter: "))
if (number<0):
    number = number*-1 
    print(number)

   #Challenge3
firstnumber = int(input("Enter: "))
secondnumber = int(input("enter: "))
print(firstnumber + secondnumber)
 
   #Challenge4
firstnumber = int(input("Enter: "))
secondnumber = int(input("enter: "))
if (firstnumber == secondnumber):
    print("numbers are equal")
if (firstnumber != secondnumber):
    print("number are not equal")

   #Challenge5
firstnumber = int(input("Enter: "))
secondnumber = int(input("enter: "))
if (firstnumber + secondnumber) < 20:
    print("sum is less than 20")
if (firstnumber + secondnumber) > 20:
    print("sum is grater than 20")

   # Challenge6
score = int(input("Enter: "))
if (score < 50):
    print("Bad")
if (50 < score < 80):
    print("Not good, Not bad")
if (80 < score < 100):
    print("Excellent!")
if (score > 100):
    print("Are you crazy?")
 
   #Challenge7
firstnumber = int(input("Enter: "))
secondnumber = int(input("enter: "))
if (firstnumber > secondnumber): 
    print("Greatest number is: ",firstnumber)
if (firstnumber < secondnumber):
    print("Greatest number is: ",secondnumber)

   #Challenge8
firstnumber = int(input("Enter: "))
secondnumber = int(input("enter: "))
if (firstnumber < secondnumber): 
    print("Smallest number is: ",firstnumber)
if (firstnumber > secondnumber):
    print("Smallest number is: ",secondnumber)

   #Challenge 9
firstnumber = int(input("Enter: "))
secondnumber = int(input("Enter: "))
thirdnumber = int(input("Enter: "))
if (firstnumber == secondnumber== thirdnumber):
    print("All equal")
else:
    print("Not all equal")

    #Challenge10
firstnumber = int(input("Enter: "))
secondnumber = int(input("Enter: "))
thirdnumber = int(input("Enter: "))
if (firstnumber > secondnumber and thirdnumber): 
    print("Greatest number is: ",firstnumber)
if (firstnumber and thirdnumber < secondnumber):
    print("Greatest number is: ",secondnumber)
if(thirdnumber > firstnumber and secondnumber):
    print("Greatest number is: ", thirdnumber)

    #Challenge11
firstnumber = int(input("Enter: "))
secondnumber = int(input("Enter: "))
thirdnumber = int(input("Enter: "))
if (firstnumber < secondnumber < thirdnumber): 
    print("Lowest number is: ",firstnumber)
if (firstnumber > thirdnumber > secondnumber):
    print("Lowest number is: ",secondnumber)
if(thirdnumber < firstnumber < secondnumber):
    print("Lowest number is: ",thirdnumber)

    #Challenge12
number1 = int(input("Enter: "))
number2 = int(input("Enter: "))
number3 = int(input("Enter: "))
number4 = int(input("Enter: "))
if (number1*number2 > number3*number4):
    print("Smaller")
if (number1*number2 < number3*number4):
    print("Greater")
    
    #Challenge13
myNumber = int(input("Enter: "))
if (myNumber!= 20):
    print("Try again!")
else:
    print("You won!")
    
    #Challenge14
iswon =False
while not iswon:
    myname = input("Enter: ")
    if myname != "Sisamuth":
        print("Try again!")
    else:
        iswon = True
        print("You won!")

