#  Hackerange16#
#    EX1
# text = input()
# numberisA =""
# for i in range(len(text)):
#     if text[i] =="A"or text[i]=="a":
#         numberisA += "*"
#     else:
#         numberisA += text[i]
# print(numberisA)

    #EX2
# word = int(input())
# text = ""
# for i in range(word):
#     text+= "X"
#     print(text)
    #EX2
# word = int(input())
# text = ""
# for i in range(word):
#     for u in range(i+1):
#         text += "X"
#     text+= "\n"
# print(text)
     
     #EX3
# word = int(input())
# text = ""
# for i in range(word):
#     for o in range(i-1):
#         text+=" "
#     for all in range(o+1):
#         text += "X"      
#     text+= "\n"
# print(text)

  

    #EX4
number = int(input())
for i in range(number):
    for j in range(number-i-1):
        print(" ",end=" ")
    for j in range (2*i+1):
        print("@",end=" ")
    print()
  
   #EX5




    

