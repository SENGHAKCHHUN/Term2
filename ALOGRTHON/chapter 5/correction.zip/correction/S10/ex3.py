number = int(input())
sum = 0
i = 1
result = ""
while i < number +1 :
    sum += 1
    result += str(sum) + " "
    i +=1
print(result)
print(sum)