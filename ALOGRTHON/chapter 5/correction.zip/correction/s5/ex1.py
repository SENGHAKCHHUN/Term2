number = input()
isStop = False
for i in range(len(number)):
    if number[i] == '7':
        isStop = True
print(isStop)
