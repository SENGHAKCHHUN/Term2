# text = input()
# i = 0
# result = "NO"
# while i<len(text):
#     if text[i] == 'R' or text[i] == 'r' or text[i] and text[i+1]=='a' and text[i+2] =='d' and text[i+3] =='y':
#         result = "YES"
#         i += 1
#     else:
#         i +=1
# print(result)


# text = input()
# result = ""
# word = ""
# isFound = False
# for i in range(len(text)):
#     if text[i]==" " or i==len(text)-1:
#         if i == len(text)-1 and text[i] != '.' and text[i] != '!' and text[i] != '?':
#             word += text[i]
            
#         if word.upper() == "RADY":
#             isFound = True
#         word = ""
#     else:
#         if text[i] != '.' and text[i] != '!' and text[i] != '?' :
#             word+=text[i]
# if isFound:
#     print("YES")
# else:
#     print("No")

""
       
            

