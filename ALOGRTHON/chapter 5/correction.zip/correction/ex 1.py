number = int(input())
result =""
for i in range(number):
    result = result + str(number-i) + " "
print(result)

