n1 = int(input())
n2 = int(input())
sum = 0
if n2 > n1:
    sum = n1 + n2
else:
    sum = -1
print(sum)