text = input()
result= -1
for i in range(len(text)):
    if text[i] =='K' or text[i] == 'k':
        result = i
print(result)


    