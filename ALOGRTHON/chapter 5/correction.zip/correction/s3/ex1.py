n = int(input())
inRange = False
if n >= 1 and n<=10:
    inRange = True
elif n >=29 and n <=51:
    inRange = True
elif n >=76 and n <=101:
    inRange = True
print(inRange)