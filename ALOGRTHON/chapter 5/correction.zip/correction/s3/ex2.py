# text = input()
# sum = 0
# result = 0
# sum1 = 0
# for  i in range(len(text)):
#     if text[i]=='A' or text[i] =='a':
#         sum = 10
#     elif text[i] == 'B' or text[i] == 'b':
#         result= 20
#     else:
#         sum1 = 0
# print(sum + result)

