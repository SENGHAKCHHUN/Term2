def reverseString(word):
    res = ""
    total = ""
    for i in range(len(word)):
        text = word[i]
        for j in range(len(text)):
            res += text[-1-j]
        total += "The reversed of " + word[i] + " is " + res +"\n"
        res = ""
    return total
word = eval(input())
print(reverseString(word))
