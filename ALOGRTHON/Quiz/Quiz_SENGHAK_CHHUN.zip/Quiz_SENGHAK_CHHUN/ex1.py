def CountNumberOfA(array):
    count = 0
    total = ""
    for i in range(len(array)):
        word = array[i]
        for j in range(len(word)):
            if word[j] == 'a' or word[j] == 'A':
                count +=1
        total += "Number of A in " + array[i] + " is " + str(count) +"\n"
        count = 0
    return total
array = eval(input())
print(CountNumberOfA(array))


