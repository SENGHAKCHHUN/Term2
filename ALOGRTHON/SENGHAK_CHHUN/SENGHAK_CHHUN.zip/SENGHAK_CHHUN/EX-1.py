n = int(input("enter number"))
if n <= 20 and n >= 10:
    print("Inside")
else:
    print("Outside")