array2D = [
    ['*','*','*'],
    ['0','0','0'],
    ['0','0','0']
]
for i in range(len(array2D)):
    bool = True
    j = 0
    while j < len(array2D[i]) and bool:
        sign = array2D[i][0]
        if array2D[i][j] == sign:
            bool = True
        else:
            bool = False
        j +=1
    if bool:
        print("win")
            
    


